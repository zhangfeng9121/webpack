<!-- 入口组件 -->
<template>
	<div>
       <!-- <mt-header fixed title="上海资信"></mt-header> -->
    </div>
</template>

<script>
	
</script>

<style>
	
</style>